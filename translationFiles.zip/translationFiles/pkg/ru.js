﻿CKEDITOR.plugins.setLang( 'flite', 'ru', {
	TOGGLE_TRACKING: "Переключить отслеживание изменений",
	TOGGLE_SHOW: "Переключить отслеживание изменений",
	ACCEPT_ALL: "Принять все изменения",
	REJECT_ALL: "Отклонить все изменения",
	ACCEPT_ONE: "Принять изменение",
	REJECT_ONE: "Reject Change",
	START_TRACKING: "Отклонить изменение",
	STOP_TRACKING: "Прекратить отслеживание изменений",
	PENDING_CHANGES: "Ваш документ содержит некоторые ожидающие изменения.\nПожалуйста, разрешите их, прежде чем отключать отслеживание изменений.",
	HIDE_TRACKED: "Скрыть отслеженные изменения",
	SHOW_TRACKED: "Показать отслеженные изменения",
	CHANGE_TYPE_ADDED: "добавленной",
	CHANGE_TYPE_DELETED: "удаленный",
	MONTHS: ["янв", "фев", "мар", "апр", "май", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"],
	NOW: "сейчас",
	MINUTE_AGO: "1 минуту назад",
	MINUTES_AGO: "%Minutes минут назад",
	BY: "от",
	ON: "на",
	AT: "на",
	FLITE_LABELS_DATE: function(day, month, year)
	{
		if(typeof(year) != 'undefined') {
			year = ", " + year;
		}
		else {
			year = "";
		}
		return this.MONTHS[month] + " " + day + year;
	}
});