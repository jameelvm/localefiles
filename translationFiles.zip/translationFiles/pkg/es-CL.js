﻿CKEDITOR.plugins.setLang('flite', 'es-CL', {
    TOGGLE_TRACKING: "Alternar cambios de seguimiento",
    TOGGLE_SHOW: "Alternar cambios de seguimiento",
    ACCEPT_ALL: "Aceptar todos los cambios",
    REJECT_ALL: "Rechazar todos los cambios",
    ACCEPT_ONE: "Aceptar cambio",
    REJECT_ONE: "Rechazar el cambio",
    START_TRACKING: "Iniciar el seguimiento de los cambios",
    STOP_TRACKING: "Dejar de rastrear cambios",
    PENDING_CHANGES: "Su documento contiene algunos cambios pendientes.\nPor favor, resuélvelos antes de desactivar el seguimiento de cambios.",
    HIDE_TRACKED: "Ocultar cambios rastreados",
    SHOW_TRACKED: "Mostrar cambios rastreados",
    CHANGE_TYPE_ADDED: "adicional",
    CHANGE_TYPE_DELETED: "eliminado",
    MONTHS: ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"],
    NOW: "now",
    MINUTE_AGO: "1 minute ago",
    MINUTES_AGO: "%Minutes minutes ago",
    BY: "by",
    ON: "on",
    AT: "on",
    FLITE_LABELS_DATE: function (day, month, year) {
        if (typeof (year) != 'undefined') {
            year = ", " + year;
        }
        else {
            year = "";
        }
        return this.MONTHS[month] + " " + day + year;
    }
});