﻿CKEDITOR.plugins.setLang('flite', 'zh', {
    TOGGLE_TRACKING: "切换跟踪更改",
    TOGGLE_SHOW: "切换跟踪更改",
    ACCEPT_ALL: "接受所有更改",
    REJECT_ALL: "拒绝所有更改",
    ACCEPT_ONE: "接受更改",
    REJECT_ONE: "拒绝更改",
    START_TRACKING: "开始跟踪更改",
    STOP_TRACKING: "停止跟踪更改",
    PENDING_CHANGES: "您的文档包含一些待定更改. \n请在关闭更改跟踪之前解决它们.",
    HIDE_TRACKED: "隐藏跟踪的更改",
    SHOW_TRACKED: "显示跟踪的更改",
    CHANGE_TYPE_ADDED: "添加",
    CHANGE_TYPE_DELETED: "删除",
    MONTHS: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
    NOW: "现在",
    MINUTE_AGO: "一分钟前",
    MINUTES_AGO: "%Minutes 几分钟前",
    BY: "通过",
    ON: "上",
    AT: "上",
    FLITE_LABELS_DATE: function (day, month, year) {
        if (typeof (year) != 'undefined') {
            year = ", " + year;
        }
        else {
            year = "";
        }
        return this.MONTHS[month] + " " + day + year;
    }
});