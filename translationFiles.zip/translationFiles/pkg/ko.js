﻿CKEDITOR.plugins.setLang( 'flite', 'en', {
    TOGGLE_TRACKING: "추적 변경 토글",
    TOGGLE_SHOW: "추적 변경 토글",
    ACCEPT_ALL: "모든 변경 사항 수락",
	REJECT_ALL: "모든 변경 사항을 거부합니다.",
	ACCEPT_ONE: "변경 사항 수락",
	REJECT_ONE: "변경 거부",
	START_TRACKING: "변경 내용 추적 시작",
	STOP_TRACKING: "변경 내용 추적 중지",
	PENDING_CHANGES: "문서에 보류중인 변경 사항이 있습니다.\n변경 내용 추적을 사용 중지하기 전에 문제를 해결하십시오.",
	HIDE_TRACKED: "추적 된 변경 사항 숨기기",
	SHOW_TRACKED: "추적 된 변경 사항 표시",
	CHANGE_TYPE_ADDED: "추가 된",
	CHANGE_TYPE_DELETED: "삭제 된",
	MONTHS: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
	NOW: "지금",
	MINUTE_AGO: "1 분 전",
	MINUTES_AGO: "%Minutes 몇분 전에",
	BY: "으로",
	ON: "...에",
	AT: "...에",
	FLITE_LABELS_DATE: function(day, month, year)
	{
		if(typeof(year) != 'undefined') {
			year = ", " + year;
		}
		else {
			year = "";
		}
		return this.MONTHS[month] + " " + day + year;
	}
});