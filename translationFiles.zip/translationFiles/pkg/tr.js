﻿CKEDITOR.plugins.setLang( 'flite', 'tr', {
    TOGGLE_TRACKING: "İzleme Değişikliklerini Değiştir",
    TOGGLE_SHOW: "İzleme Değişikliklerini Değiştir",
    ACCEPT_ALL: "Tüm değişiklikleri kabul et",
    REJECT_ALL: "Tüm değişiklikleri reddet",
    ACCEPT_ONE: "Değişikliği Kabul Et",
    REJECT_ONE: "Değişikliği Reddet",
    START_TRACKING: "Değişiklikleri izlemeye başla",
    STOP_TRACKING: "Değişiklikleri izlemeyi durdur",
    PENDING_CHANGES: "Belgeniz bekleyen bazı değişiklikler içeriyor.\nLütfen değişiklik izlemeyi kapatmadan önce bunları çözün.",
    HIDE_TRACKED: "İzlenen değişiklikleri gizle",
    SHOW_TRACKED: "İzlenen değişiklikleri göster",
    CHANGE_TYPE_ADDED: "katma",
    CHANGE_TYPE_DELETED: "silindi",
    MONTHS: ["Oca", "Åžub", "Mar", "Nis", "May", "Haz", "Tem", "AÄŸu", "Eyl", "Eki", "Kas", "Ara"],
    NOW: "şimdi",
    MINUTE_AGO: "1 bir dakika önce",
    MINUTES_AGO: "%Minutes Dakika önce",
    BY: "tarafından",
    ON: "üzerinde",
	AT: "üzerinde",
	FLITE_LABELS_DATE: function(day, month, year)
	{
		if(typeof(year) != 'undefined') {
			year = ", " + year;
		}
		else {
			year = "";
		}
		return this.MONTHS[month] + " " + day + year;
	}
});